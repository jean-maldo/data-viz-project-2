# data-viz-project-2

This is the git repository for INFO 5100 - Visual Data Analytics for the Web

The project will look to visualize tsunamis and the earthquakes or/and volcanos that caused them. The data that will be visualized is for the years of 1950 to 2017. The data was obtained from the National Oceanic and Atmospheric Administration's website (https://www.ngdc.noaa.gov/hazard/hazards.shtml)

Datasets for the Tsunami, Earthquake, Volcano disasters were all obtained from the same source.
